package com.sbagoudou.evaluation3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Evaluation3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
